# Portfolio Analysis Dashboard (Python)

A beginner-friendly Streamlit project for analyzing a portfolio from a CSV file.

## Features
- Current market value and cost basis
- Unrealized profit/loss and return percentage
- Asset and sector allocation charts
- Per-asset profit/loss and return charts
- Concentration checks (largest holding, largest sector, HHI)
- Automated summary and downloadable analyzed CSV
- Includes sample data so it can run immediately

## Requirements
Python 3.10 or newer recommended.

## Run locally
1. Extract the ZIP file.
2. Open a terminal in this folder.
3. Install packages:
   ```bash
   python -m pip install -r requirements.txt
   ```
4. Start the dashboard:
   ```bash
   streamlit run app.py
   ```
5. Open the local URL Streamlit displays.

## CSV format
Your CSV must include these columns exactly:

| Column | Meaning |
|---|---|
| `Asset` | Name or ticker |
| `Quantity` | Number of units held |
| `Purchase_Price` | Average purchase price per unit |
| `Current_Price` | Current price per unit you enter |
| `Sector` | Sector/category |

Keep all prices in one currency. The app does not download live prices. Replace the sample data or upload your own CSV using the sidebar.

## How the calculations work
- Cost basis = Quantity × Purchase Price
- Market value = Quantity × Current Price
- Unrealized P/L = Market Value − Cost Basis
- Return (%) = Unrealized P/L ÷ Cost Basis × 100
- Portfolio weight (%) = Market Value ÷ Total Market Value × 100
- HHI = sum of squared fractional asset weights; higher values indicate greater concentration.

## Important limitations
This is an educational analysis tool, not financial advice. It does not account for fees, taxes, dividends, cash flows, or multiple currencies. Results are only as accurate as the input prices and holdings.
