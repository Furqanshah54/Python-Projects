import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(page_title="Portfolio Analysis", page_icon="📊", layout="wide")
st.title("📊 Portfolio Analysis Dashboard")
st.caption("Analyze holdings, allocation, profit/loss, and concentration. Upload your own CSV or use the sample data.")

REQUIRED = ["Asset", "Quantity", "Purchase_Price", "Current_Price", "Sector"]

def prepare(df):
    df = df.copy()
    for c in ["Quantity", "Purchase_Price", "Current_Price"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["Asset"] = df["Asset"].astype(str).str.strip()
    df["Sector"] = df["Sector"].fillna("Unclassified").astype(str).str.strip()
    df = df.dropna(subset=["Asset", "Quantity", "Purchase_Price", "Current_Price"])
    df = df[(df["Quantity"] >= 0) & (df["Purchase_Price"] >= 0) & (df["Current_Price"] >= 0)]
    df["Cost_Basis"] = df["Quantity"] * df["Purchase_Price"]
    df["Market_Value"] = df["Quantity"] * df["Current_Price"]
    df["Profit_Loss"] = df["Market_Value"] - df["Cost_Basis"]
    df["Return_Pct"] = df.apply(lambda r: (r["Profit_Loss"] / r["Cost_Basis"] * 100) if r["Cost_Basis"] else 0, axis=1)
    total = df["Market_Value"].sum()
    df["Weight_Pct"] = df["Market_Value"] / total * 100 if total else 0
    return df

sample_path = Path(__file__).parent / "sample_portfolio.csv"
with st.sidebar:
    st.header("Data")
    uploaded = st.file_uploader("Upload portfolio CSV", type=["csv"])
    st.markdown("**Required columns:**")
    st.code("Asset, Quantity, Purchase_Price, Current_Price, Sector")
    st.caption("Prices and currency units must be consistent (e.g. all PKR or all USD).")

try:
    raw = pd.read_csv(uploaded) if uploaded else pd.read_csv(sample_path)
except Exception as e:
    st.error(f"Could not read CSV: {e}")
    st.stop()

missing = [c for c in REQUIRED if c not in raw.columns]
if missing:
    st.error("Missing required columns: " + ", ".join(missing))
    st.stop()

df = prepare(raw)
if df.empty:
    st.warning("No valid holdings found. Check that quantity and prices are numeric and non-negative.")
    st.stop()

total_value = df["Market_Value"].sum()
total_cost = df["Cost_Basis"].sum()
total_pl = df["Profit_Loss"].sum()
overall_return = total_pl / total_cost * 100 if total_cost else 0
best = df.loc[df["Return_Pct"].idxmax()]
worst = df.loc[df["Return_Pct"].idxmin()]
largest = df.loc[df["Weight_Pct"].idxmax()]

def money(x):
    return f"{x:,.2f}"

c1, c2, c3, c4 = st.columns(4)
c1.metric("Current portfolio value", money(total_value))
c2.metric("Total cost basis", money(total_cost))
c3.metric("Unrealized profit / loss", money(total_pl), f"{overall_return:.2f}%")
c4.metric("Number of holdings", f"{len(df)}")

st.subheader("Holdings breakdown")
display_cols = ["Asset", "Sector", "Quantity", "Purchase_Price", "Current_Price", "Cost_Basis", "Market_Value", "Profit_Loss", "Return_Pct", "Weight_Pct"]
fmt = {c: "{:,.2f}" for c in ["Purchase_Price","Current_Price","Cost_Basis","Market_Value","Profit_Loss","Return_Pct","Weight_Pct"]}
st.dataframe(df[display_cols].style.format(fmt), use_container_width=True, hide_index=True)

left, right = st.columns(2)
with left:
    st.subheader("Asset allocation")
    fig = px.pie(df, names="Asset", values="Market_Value", hole=0.42)
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader("Sector allocation")
    sector = df.groupby("Sector", as_index=False)["Market_Value"].sum().sort_values("Market_Value", ascending=False)
    fig = px.bar(sector, x="Sector", y="Market_Value", color="Sector", title=None)
    st.plotly_chart(fig, use_container_width=True)

left, right = st.columns(2)
with left:
    st.subheader("Profit / loss by asset")
    pl = df.sort_values("Profit_Loss", ascending=True)
    fig = px.bar(pl, x="Profit_Loss", y="Asset", orientation="h", color="Profit_Loss",
                 color_continuous_midpoint=0)
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader("Return by asset")
    ret = df.sort_values("Return_Pct", ascending=True)
    fig = px.bar(ret, x="Return_Pct", y="Asset", orientation="h", color="Return_Pct",
                 color_continuous_midpoint=0, labels={"Return_Pct": "Return (%)"})
    st.plotly_chart(fig, use_container_width=True)

st.subheader("Portfolio health checks")
top_weight = largest["Weight_Pct"]
hhi = ((df["Weight_Pct"] / 100) ** 2).sum()
sector_weights = sector["Market_Value"] / total_value if total_value else pd.Series(dtype=float)
top_sector_weight = float(sector_weights.max() * 100) if len(sector_weights) else 0
checks = [
    ("Largest single holding", f"{largest['Asset']} ({top_weight:.1f}% of portfolio)",
     "High concentration" if top_weight >= 30 else "Moderate concentration" if top_weight >= 20 else "Relatively spread"),
    ("Largest sector", f"{sector.loc[sector['Market_Value'].idxmax(), 'Sector']} ({top_sector_weight:.1f}%)" if len(sector) else "N/A",
     "Review sector exposure" if top_sector_weight >= 50 else "No dominant sector above 50%"),
    ("Diversification (HHI)", f"{hhi:.3f}", "More concentrated" if hhi >= 0.25 else "Moderately concentrated" if hhi >= 0.15 else "More distributed"),
    ("Best performer", f"{best['Asset']} ({best['Return_Pct']:.2f}%)", "Past return does not guarantee future performance"),
    ("Weakest performer", f"{worst['Asset']} ({worst['Return_Pct']:.2f}%)", "Review the investment thesis; avoid decisions from return alone"),
]
st.table(pd.DataFrame(checks, columns=["Metric", "Result", "Interpretation"]))

st.subheader("Automated summary")
direction = "gain" if total_pl > 0 else "loss" if total_pl < 0 else "break-even"
st.write(f"The portfolio's current estimated value is **{money(total_value)}**, with an unrealized **{direction} of {money(abs(total_pl))} ({overall_return:.2f}% relative to recorded cost basis)**.")
st.write(f"**{largest['Asset']}** is the largest position at **{top_weight:.1f}%**. The strongest recorded return is **{best['Asset']}** and the weakest is **{worst['Asset']}**.")
if top_weight >= 30:
    st.warning("One holding represents at least 30% of portfolio value. Consider whether this concentration matches your risk tolerance and plan.")
if top_sector_weight >= 50:
    st.warning("One sector represents at least 50% of portfolio value. Sector-specific events could materially affect results.")
st.info("This dashboard is educational, not personalized financial advice. It uses only the prices you enter, does not fetch live prices, and does not account for fees, taxes, dividends, deposits, withdrawals, or currency differences.")

st.download_button("Download analyzed holdings CSV", data=df[display_cols].to_csv(index=False).encode("utf-8"),
                   file_name="portfolio_analysis.csv", mime="text/csv")
